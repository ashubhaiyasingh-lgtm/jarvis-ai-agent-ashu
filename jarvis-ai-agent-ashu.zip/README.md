# JARVIS AI Assistant

Mobile-first installable PWA prototype for iPhone.

Features: Hindi/English UI, voice input/output where supported, document quick actions, file picker, PWA installation.

Real AI processing requires a secure server-side AI backend; never put API secrets in browser code.
